<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" type="text/css" rel="stylesheet">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       <style>

body {
                font-family: 'Nunito', sans-serif;
            }
            h4
            {
                align-items:right;
                float:right;
            }
            .main{
                width: 330px;
                border:02px solid green;
                padding: 6px;
                border-radius:30px;
            }
  </style>
        
</head>
<body>
             <div class="logo">
                            <a href="#"><img src="assets/img/De-logo.png" alt="Logo" style="width:auto;max-height:50px;"></a>
             </div>
<h4 > {{ menu('main','bootstrap') }}</h4>
</br>
<!-- <div>
<h2>{{"Hello  Celebrities i am here to share your happiness with people"}}</h2>
</div> -->
</body>
</html>