@include("header")
<section class="">
     <div class="container">
     <div class="row celeb_wrap_list">
         <div class="col-lg-5 celeb-thumbnail"><img src="images/thnl-1.png"></div>
         <div class="col-lg-7 celeb_cont">
           <p class="celeb_name">ANJALI ABROL</p>
           <p class="celeb_profession">Indian film director, producer, screenwriter and television host</p>
           <ul class="rating_list list-unstyled d-flex">
            <p class="text-dark mb-0">Rating:</p>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-grey.png"></a></li>
          </ul>
          <ul class=" main-info-list list-unstyled">
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>            
          </ul>
          <p>Norem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.</p>
          <a class="more-data" href="{{url('/profile')}}">Know More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
         </div>
       </div>
       <div class="row celeb_wrap_list">
         <div class="col-lg-5 celeb-thumbnail"><img src="images/celeb-list-1.png"></div>
         <div class="col-lg-7 celeb_cont">
           <p class="celeb_name">KARAN JOHAR</p>
           <p class="celeb_profession">Indian film director, producer, screenwriter and television host</p>
           <ul class="rating_list list-unstyled d-flex">
            <p class="text-dark mb-0">Rating:</p>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-grey.png"></a></li>
          </ul>
          <ul class=" main-info-list list-unstyled">
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>            
          </ul>
          <p>Norem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.</p>
          <a class="more-data" href="{{url('/profile')}}">Know More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
         </div>
       </div>
       <div class="row celeb_wrap_list">
         <div class="col-lg-5 celeb-thumbnail"><img src="images/Rectangle.png"></div>
         <div class="col-lg-7 celeb_cont">
           <p class="celeb_name">AISHWARYA RAI</p>
           <p class="celeb_profession">Indian film director, producer, screenwriter and television host</p>
           <ul class="rating_list list-unstyled d-flex">
            <p class="text-dark mb-0">Rating:</p>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-grey.png"></a></li>
          </ul>
          <ul class=" main-info-list list-unstyled">
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>            
          </ul>
          <p>Norem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.</p>
          <a class="more-data" href="{{url('/profile')}}">Know More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
         </div>
       </div>
       <div class="row celeb_wrap_list">
         <div class="col-lg-5 celeb-thumbnail"><img src="images/celeb-list-1.png"></div>
         <div class="col-lg-7 celeb_cont">
           <p class="celeb_name">KARAN JOHAR</p>
           <p class="celeb_profession">Indian film director, producer, screenwriter and television host</p>
           <ul class="rating_list list-unstyled d-flex">
            <p class="text-dark mb-0">Rating:</p>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-grey.png"></a></li>
          </ul>
          <ul class=" main-info-list list-unstyled">
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>            
          </ul>
          <p>Norem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.</p>
          <a class="more-data" href="{{url('/profile')}}">Know More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
         </div>
       </div>
       <div class="row celeb_wrap_list">
         <div class="col-lg-5 celeb-thumbnail"><img src="images/top-person-1.png"></div>
         <div class="col-lg-7 celeb_cont">
           <p class="celeb_name">ANUSKHA SHARMA</p>
           <p class="celeb_profession">Indian film director, producer, screenwriter and television host</p>
           <ul class="rating_list list-unstyled d-flex">
            <p class="text-dark mb-0">Rating:</p>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-grey.png"></a></li>
          </ul>
          <ul class=" main-info-list list-unstyled">
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>            
          </ul>
          <p>Norem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.</p>
          <a class="more-data" href="{{url('/profile')}}">Know More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
         </div>
       </div>
       <div class="row celeb_wrap_list">
         <div class="col-lg-5 celeb-thumbnail"><img src="images/celeb-list-1.png"></div>
         <div class="col-lg-7 celeb_cont">
           <p class="celeb_name">KARAN JOHAR</p>
           <p class="celeb_profession">Indian film director, producer, screenwriter and television host</p>
           <ul class="rating_list list-unstyled d-flex">
            <p class="text-dark mb-0">Rating:</p>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-grey.png"></a></li>
          </ul>
          <ul class=" main-info-list list-unstyled">
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>            
          </ul>
          <p>Norem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.</p>
          <a class="more-data" href="{{url('/profile')}}">Know More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
         </div>
       </div>
       <div class="row celeb_wrap_list">
         <div class="col-lg-5 celeb-thumbnail"><img src="images/celeb-list-1.png"></div>
         <div class="col-lg-7 celeb_cont">
           <p class="celeb_name">KARAN JOHAR</p>
           <p class="celeb_profession">Indian film director, producer, screenwriter and television host</p>
           <ul class="rating_list list-unstyled d-flex">
            <p class="text-dark mb-0">Rating:</p>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-filled.png"></a></li>
            <li><a href="#"><img src="images/star-grey.png"></a></li>
          </ul>
          <ul class=" main-info-list list-unstyled">
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>
            <li class="d-flex"><p class="mb-0">Date of Birth:</p> <p class="mb-0">May 25, 1972</p> </li>            
          </ul>
          <p>Norem ipsum dolor sit amet, consectetur adipiscing elit. Nunc vulputate libero et velit interdum, ac aliquet odio mattis.</p>
          <a class="more-data" href="{{url('/profile')}}">Know More <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
         </div>
       </div>
      
     </div>
      <div class="row next-prev">
         <div class="col-12 text-center">
          <a class="previ" href="{{url('/alllisting')}}"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
          <a class="next" href="{{url('/alllisting')}}"><i class="fa fa-angle-right" aria-hidden="true"></i></a></div>
       </div>
   </section>
@include("footer")
